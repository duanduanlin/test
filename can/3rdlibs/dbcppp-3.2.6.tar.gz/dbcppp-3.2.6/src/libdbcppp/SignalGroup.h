
#pragma once

namespace dbcppp
{
    class SignalGroup
    {
    public:
    private:
    };
}
