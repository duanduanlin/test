#pragma once

namespace dbcppp
{
    enum class Endian
    {
        Little,
        Big,
        Native = Little,
    };
}
